export const metadata = {
    title: 'Test'
};

export default function Page() {
    return (
        <div className="flex flex-col gap-6 sm:gap-12">
           a page
        </div>
    );
}
